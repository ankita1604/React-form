import React from "react";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import registrationForm from "./App.js";
function App() {
  return (
    <div className="App">
      <SimpleForm />
    </div>
  );
}
export default App;
